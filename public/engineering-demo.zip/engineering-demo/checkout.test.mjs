import test from 'node:test';
import assert from 'node:assert/strict';
import {total} from './checkout.mjs';
test('two items cost unit price times quantity', () => assert.equal(total(12, 2), 24));
